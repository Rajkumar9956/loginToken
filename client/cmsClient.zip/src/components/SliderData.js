import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ApiUrls from './ApiUrls/ApiUrls';
import { Link } from 'react-router-dom';


const SliderData = () => {
    const [data, setData] = useState();
    const [mainTitle, setMainTitle] = useState();
    const [description, setDescription] = useState();
    const [singleData, setSingleData] = useState();
    const [id, setId] = useState();
    useEffect(() => {
        axios.get(ApiUrls.apiUrl + 'get-slider').then((res) => {
            setData(res.data)
        })
    }, []);
    const activateStatus = (e, id) => {

        if (window.confirm('Are you sure you want to DeActivete this item?')) {
            console.log("E", e);
            console.log("id", id);
            const data = {
                status: e,
                id: id,
            }
            axios.post(ApiUrls.apiUrl + 'status-update', data).then((res) => {
                setData(res.data)
            })
        }

    }

    const deleteData = (id) => {
        if (window.confirm('Are you sure you want to Delete this item?')) {
            axios.post(ApiUrls.apiUrl + 'dalete-data', { id }).then((res) => {
                setData(res.data)
            })
        }
    }

    const editSlider = (id) => {
        setId(id)
        axios.post(ApiUrls.apiUrl + 'update-slider-id', { id }).then((res) => {
            // setSingleData(res.data)
            setMainTitle(res.data.mainTitle)
            setDescription(res.data.description)
            console.log("res.data", res.data);
        })
    }

    const sliderSubmit = (e) => {
        e.preventDefault()
        console.log("Dsdsddddd", mainTitle);
        const formData = new FormData()
        formData.append('mainTitle', mainTitle)
        formData.append('description', description)
        // formData.append('sliderImage', sliderImage)  
        formData.append('_id', id)
        console.log("formData", formData);

        axios.post(ApiUrls.apiUrl + 'home-slider-update', formData).then((res) => {
            console.log("asaad", res);
            setData(res.data.data)

            setMainTitle('');
            setDescription('');
            document.getElementById("formFile").value = "";

        }).catch((err) => {
            if (err) {
                //  toast.error("Something is Else !");
            }
        })
    }
    return (

        <>

            <section className="section">
                <div className="row">
                    <div className="col-lg-3">
                    </div>
                    <div className="col-lg-9">

                        <div className="card">
                            <div className="card-body">
                                <h5 className="card-title">Default Table</h5>

                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Main Tittle</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Image</th>
                                            <th scope="col">Action</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {data && data.map((da, idx) => {
                                            return <tr>
                                                <th scope="row">{idx + 1}</th>
                                                <td>{da.mainTitle}</td>
                                                <td>{da.description}</td>
                                            
                                                <td><img src={`assets/uploads/${da.sliderImage}`} alt="Girl in a jacket" width="100" height="100"/></td>
                                                <td><button type="button" onClick={(e) => deleteData(da._id)} class="btn btn-danger">Delete</button>     <button type="button" onClick={(e) => editSlider(da._id)} class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" >Edit</button> </td>
                                                <td onClick={(e) => activateStatus(da.status, da._id)}>{da.status == 0 ? <button type="button" class="btn btn-success">Activate</button> : null}{da.status == 1 ? <button type="button" class="btn btn-danger">DeActivate</button> : null}</td>
                                            </tr>
                                        })}
                                    </tbody>
                                </table>
                                Example
                                <Link to="/home-form">Back to Home Form</Link>

                            </div>

                        </div>

                    </div>


                </div>
            </section>

            <section>



                <div className="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Edit Slider Data</h5>
                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div className="modal-body">
                                <form onSubmit={sliderSubmit}>
                                    <div className="mb-3">
                                        <label htmlfor="recipient-name" className="col-form-label">Main Title:</label>
                                        <input type="text" className="form-control" id="recipient-name" defaultValue={mainTitle} onChange={(e) => setMainTitle(e.target.value)} />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlfor="message-text" className="col-form-label">Description:</label>
                                        <textarea className="form-control" id="message-text" defaultValue={description} onChange={(e) => setDescription(e.target.value)}></textarea>
                                    </div>
                                    <div className="mb-3">
                                        <label htmlfor="recipient-name" className="col-form-label">Slider Image:</label>
                                        <input type="file" className="form-control" id="recipient-name" />
                                    </div>
                                    <div className="modal-footer">
                                        <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" className="btn btn-primary">Send message</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}

export default SliderData