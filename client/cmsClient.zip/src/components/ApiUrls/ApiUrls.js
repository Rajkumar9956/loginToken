module.exports = {
    apiUrl:"http://localhost:5020/",

}
